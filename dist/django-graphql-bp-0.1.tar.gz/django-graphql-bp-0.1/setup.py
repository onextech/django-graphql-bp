from distutils.core import setup

setup(
    name='django-graphql-bp',
    packages=['django-graphql-bp'],  # this must be the same as the name above
    version='0.1',
    description='Boiler plate for API projects based on Django 2 and graphql (graphene) 2',
    author='Artsem Stalavitski',
    author_email='a.stalavitski@gmail.com',
    url='https://github.com/one-x-tech/django-graphql-bp',  # use the URL to the github repo
    download_url='https://github.com/one-x-tech/django-graphql-bp/archive/0.1.tar.gz',  # I'll explain this in a second
    keywords=['django', 'graphql', 'graphene', 'crud'],  # arbitrary keywords
    classifiers=[],
)
